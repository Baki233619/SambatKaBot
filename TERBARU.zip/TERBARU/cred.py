#Twilio Details

account_sid = 'ACe90eee1c6869a262e75c0759aa5eb179'
auth_token = 'cb8cb24936347954e7d24c862a1f5369'
twilionumber = '+19035825434'
twiliosmsnumber = '+19035825434'

#FC Bot
API_TOKEN = "8043716544:AAHbZY-q6_Oc_0UxbAQqNhaTzYiKy8qIruI"

#Host URL
callurl = 'https://9dd1-2404-7c00-52-467e-187c-f547-6a12-6b82.ngrok-free.app'
twiliosmsurl = 'https://9dd1-2404-7c00-52-467e-187c-f547-6a12-6b82.ngrok-free.app/sms'









